package chad.mathquiz;

public class Score extends MainActivity implements Comparable<Score>
{
    //score date and number
    private String scoreDate;
    public int scoreNum;

    // constructor
    public Score(String date, int num)
    {
        scoreDate=date;
        scoreNum=num;
    }

    // return 1 if passed greater than this
    // -1 if this greater than passed
    // else return 0 if equal
    public int compareTo(Score sc)
    {
        return sc.scoreNum>scoreNum? 1 : sc.scoreNum<scoreNum? -1 : 0;
    }

    public String getScoreText()
    {
        return scoreDate+" - "+scoreNum;
    }
}
