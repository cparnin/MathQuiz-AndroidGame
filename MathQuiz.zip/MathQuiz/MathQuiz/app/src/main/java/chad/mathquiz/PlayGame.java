package chad.mathquiz;

import android.app.Activity;
import java.util.Random;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Random;
import android.content.SharedPreferences;
import android.widget.Toast;

public class PlayGame extends Activity implements OnClickListener
{
    private final int ADD_OPERATOR = 0, SUBTRACT_OPERATOR = 1,
            MULTIPLY_OPERATOR = 2, DIVIDE_OPERATOR = 3;
    private int level = 0, answer = 0,
            operator = 0, operand1 = 0, operand2 = 0;
    private String[] operators = {"+", "-", "x", "/"};
    // for random numbers (depends on difficulty)
    private int[][] levelMin ={
            {1, 11, 21}, // add medium diff, range 11-21
            {1, 5, 10}, // sub  medium diff, range 5-10
            {2, 5, 10}, // multiply medium diff, range 5-10
            {2, 3, 5}}; // divide medium diff, range 3-5
    private int[][] levelMax = {
            {10, 25, 50}, // add hard diff, range 25-50
            {10, 20, 30}, // sub hard diff, range 20-30
            {5, 10, 15}, // multiply hard diff, range 10-15
            {10, 50, 100}}; // divide hard diff, range 50-100
    private Random random;
    private TextView question, answerTxt, scoreTxt;
    private ImageView response;
    private Button btn1, btn2, btn3, btn4, btn5,
            btn6, btn7, btn8, btn9, btn0, enterBtn, clearBtn;

    private SharedPreferences gamePrefs; // to save high scores
    public static final String GAME_PREFS = "ArithmeticFile";
    private int count = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playgame);

        gamePrefs = getSharedPreferences(GAME_PREFS, 0); // get scores

        question =  (TextView)findViewById(R.id.question);
        answerTxt = (TextView)findViewById(R.id.answer);
        response =  (ImageView)findViewById(R.id.response);
        scoreTxt =  (TextView)findViewById(R.id.score);
        response.setVisibility(View.INVISIBLE);

        // references to buttons
        btn1 = (Button)findViewById(R.id.btn1);
        btn2 = (Button)findViewById(R.id.btn2);
        btn3 = (Button)findViewById(R.id.btn3);
        btn4 = (Button)findViewById(R.id.btn4);
        btn5 = (Button)findViewById(R.id.btn5);
        btn6 = (Button)findViewById(R.id.btn6);
        btn7 = (Button)findViewById(R.id.btn7);
        btn8 = (Button)findViewById(R.id.btn8);
        btn9 = (Button)findViewById(R.id.btn9);
        btn0 = (Button)findViewById(R.id.btn0);
        enterBtn = (Button)findViewById(R.id.enter);
        clearBtn = (Button)findViewById(R.id.clear);

        // handles clicks for all
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);
        btn0.setOnClickListener(this);
        enterBtn.setOnClickListener(this);
        clearBtn.setOnClickListener(this);

        // restore state
        if(savedInstanceState!=null)
        {
            level=savedInstanceState.getInt("level");
            int exScore = savedInstanceState.getInt("score");
            scoreTxt.setText("Score: "+exScore);
        }
        else
        {
            Bundle extras = getIntent().getExtras();
            if(extras !=null)
            {
                int passedLevel = extras.getInt("level", -1);
                if(passedLevel>=0)
                    level = passedLevel;
            }
        }
        // initialize rng
        random = new Random();
        // start the game
        chooseQuestion();
    }

    // set high score if activity is about to be destroyed
    // so user does not lose high score
    protected void onDestroy()
    {
        setHighScore();
        super.onDestroy();
    }

    //save state through state changes
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState)
    {
        int exScore = getScore();
        savedInstanceState.putInt("score", exScore);
        savedInstanceState.putInt("level", level);
        super.onSaveInstanceState(savedInstanceState);
    }

    // respond to user "number" clicks
    // 10 QUESTION GAME
    @Override
    public void onClick(View view)
    {
        // enter button
        if(view.getId()==R.id.enter)
        {
            // 10 question game
            if (count < 10) {
                ++count;
                String answerContent = answerTxt.getText().toString();
                // if we have an answer
                if (!answerContent.endsWith("?")) {
                    // get the answer typed
                    int enteredAnswer = Integer.parseInt(answerContent.substring(2));
                    // update score
                    int exScore = getScore();
                    // if they got it right
                    if (enteredAnswer == answer) {
                        scoreTxt.setText("Score: " + (exScore + 1));
                        response.setImageResource(R.drawable.tick);
                        response.setVisibility(View.VISIBLE);
                    }
                    // they got it wrong
                    else
                    {
                        response.setImageResource(R.drawable.cross);
                        response.setVisibility(View.VISIBLE);
                    }
                    // get another question
                    chooseQuestion();
                }
            }
            // User answered 10 questions, START A NEW GAME
            else
            {
                Toast.makeText(getApplicationContext(), "Starting a New Game.",
                        Toast.LENGTH_LONG).show();
                count = 0;
                setHighScore();
                scoreTxt.setText("Score: 0");
                chooseQuestion();
            }
        }
        // clear button
        else if(view.getId()==R.id.clear)
        {
            answerTxt.setText("= ?");
        }
        // number button
        else
        {
            // keep the right/wrong image hidden
            response.setVisibility(View.INVISIBLE);
            // get number pressed
            int enteredNum = Integer.parseInt(view.getTag().toString());
            // decided if answer is first or second number
            if(answerTxt.getText().toString().endsWith("?"))
                answerTxt.setText("= "+enteredNum);
            else
                answerTxt.append(""+enteredNum);
        }
    } // end onClick

    // return the updated score
    private int getScore()
    {
        String scoreStr = scoreTxt.getText().toString();
        return Integer.parseInt(scoreStr.substring(scoreStr.lastIndexOf(" ")+1));
    }

    // Every question
    private void chooseQuestion()
    {
        answerTxt.setText("= ?");
        // random operation
        operator = random.nextInt(operators.length);
        operand1 = getOperand(); // random int1
        operand2 = getOperand(); // random int2
        // do want a negative answer
        if(operator == SUBTRACT_OPERATOR)
        {
            while(operand2>operand1)
            {
                operand1 = getOperand();
                operand2 = getOperand();
            }
        }
        // only want whole numbers for division quotients (or equal ints)
        else if(operator==DIVIDE_OPERATOR)
        {
            while((((double)operand1/(double)operand2)%1 > 0) || (operand1==operand2))
            {
                operand1 = getOperand();
                operand2 = getOperand();
            }
        }
        // calculate real answers
        switch(operator)
        {
            case ADD_OPERATOR:
                answer = operand1+operand2;
                break;
            case SUBTRACT_OPERATOR:
                answer = operand1-operand2;
                break;
            case MULTIPLY_OPERATOR:
                answer = operand1*operand2;
                break;
            case DIVIDE_OPERATOR:
                answer = operand1/operand2;
                break;
            default:
                break;
        }
        // display question
        question.setText(operand1+" "+operators[operator]+" "+operand2);
    }

    private int getOperand()
    {
        // return random int within correct range
        return random.nextInt(levelMax[operator][level] - levelMin[operator][level] + 1)
                + levelMin[operator][level];
    }

    // set high score method
    private void setHighScore()
    {
        // variable to get their score
        int exScore = getScore();
        if(exScore>0)
        {
            // get Shared Preferences editor
            SharedPreferences.Editor scoreEdit = gamePrefs.edit();
            // include score and date
            DateFormat dateForm = new SimpleDateFormat("dd MMMM yyyy");
            // get date
            String dateOutput = dateForm.format(new Date());
            // retrieve existing scores
            String scores = gamePrefs.getString("highScores", "");
            // if we have existing scores
            if(scores.length()>0)
            {
                // create list of score objects
                List<Score> scoreStrings = new ArrayList<Score>();
                // store high scores in specific format
                String[] exScores = scores.split("\\|");
                // create score object for each high score
                for(String eSc : exScores)
                {
                    String[] parts = eSc.split(" - ");
                    scoreStrings.add(new Score(parts[0], Integer.parseInt(parts[1])));
                }
                // score object for current score and add to list
                Score newScore = new Score(dateOutput, exScore);
                scoreStrings.add(newScore);
                // sort the scores
                Collections.sort(scoreStrings);
                // add the first ten scores, and write to Shared Preferences
                StringBuilder scoreBuild = new StringBuilder("");
                for(int i=0; i<scoreStrings.size(); i++)
                {
                    //only want ten
                    if(i>=10) break;
                    //pipe separate the score strings
                    if(i>0) scoreBuild.append("|");
                    scoreBuild.append(scoreStrings.get(i).getScoreText());
                }
                //write to prefs
                scoreEdit.putString("highScores", scoreBuild.toString());
                scoreEdit.commit();
            }
            else
            {
                scoreEdit.putString("highScores", ""+dateOutput+" - "+exScore);
                scoreEdit.commit();
            }
        }
    }
}  // end class PlayGame



